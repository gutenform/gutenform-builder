<?php

declare(strict_types=1);

namespace Gutenform\Assets;

use Gutenform\Traits\Base;
use Gutenform\Libs\Assets;

/**
 * Class Admin
 *
 * Handles admin functionalities for the Gutenform.
 *
 * @package Gutenform\Admin
 */
class Admin
{

	use Base;

	/**
	 * Script handle for Gutenform.
	 */
	const HANDLE = 'gutenform';

	/**
	 * JS Object name for Gutenform.
	 */
	const OBJ_NAME = 'wordpressPluginBoilerplate';

	/**
	 * Development script path for Gutenform.
	 */
	const DEV_SCRIPT = 'src/admin/main.jsx';

	/**
	 * List of allowed screens for script enqueue.
	 *
	 * @var array
	 */
	private $allowed_screens = array(
		'toplevel_page_gutenform',
	);

	/**
	 * Admin bootstrapper.
	 *
	 * @return void
	 */
	public function bootstrap()
	{
		add_action('admin_enqueue_scripts', array($this, 'enqueue_script'));
	}

	/**
	 * Enqueue script based on the current screen.
	 *
	 * @param string $screen The current screen.
	 */
	public function enqueue_script($screen)
	{
		if (in_array($screen, $this->allowed_screens, true)) {
			$enqueued = Assets\enqueue_asset(
				GF_DIR . '/assets/admin/dist',
				self::DEV_SCRIPT,
				$this->get_config()
			);
			if ($enqueued) {
				wp_localize_script(self::HANDLE, self::OBJ_NAME, $this->get_data());
			}
		}
	}

	/**
	 * Get the script configuration.
	 *
	 * @return array The script configuration.
	 */
	public function get_config()
	{
		return array(
			'dependencies' => array('react', 'react-dom'),
			'handle'       => self::HANDLE,
			'in-footer'    => true,
		);
	}

	/**
	 * Get data for script localization.
	 *
	 * @return array The localized script data.
	 */
	public function get_data()
	{

		return array(
			'developer' => 'prappo',
			'isAdmin'   => is_admin(),
			'apiUrl'    => rest_url(),
			'userInfo'  => $this->get_user_data(),
		);
	}

	/**
	 * Get user data for script localization.
	 *
	 * @return array The user data.
	 */
	private function get_user_data()
	{
		$username   = '';
		$avatar_url = '';

		if (is_user_logged_in()) {
			// Get current user's data .
			$current_user = wp_get_current_user();

			// Get username.
			$username = $current_user->user_login; // or use user_nicename, display_name, etc.

			// Get avatar URL.
			$avatar_url = get_avatar_url($current_user->ID);
		}

		return array(
			'username' => $username,
			'avatar'   => $avatar_url,
		);
	}
}

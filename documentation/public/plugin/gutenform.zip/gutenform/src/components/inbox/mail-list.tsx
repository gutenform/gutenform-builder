import formatDistanceToNow from "date-fns/formatDistanceToNow"

import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"

import { useMail } from "@/admin/pages/inbox/use-mail"
import { Mail as MailType } from "@/components/inbox/mail-display"

interface MailListProps {
  items: MailType[]
}

export function MailList({ items }: MailListProps) {
  const [mail, setMail] = useMail()

  return (
    <ScrollArea className="h-screen">
      <div className="flex flex-col gap-2 p-4 pt-0">
        {items.map((item) => (
          <MailItem key={item.id} item={item} isSelected={mail.selected === item.id.toString()} setMail={setMail} />
        ))}
      </div>
    </ScrollArea>
  )
}

const MailItem = ({ item, isSelected, setMail }: { item: MailType, isSelected: boolean, setMail: (mail: MailType) => void }) => {
  //fix the date to be in the correct timezone
  const date = new Date(item.date);
  date.setHours(date.getHours() + 1);
  return (
    <button
      key={item.id}
      className={cn(
        "flex flex-col items-start gap-2 rounded-lg border p-3 text-left text-sm transition-all hover:bg-accent",
        isSelected && "bg-muted"
      )}
      onClick={() =>
        setMail({
          ...mail,
          selected: item.id,
        })
      }
    >
      <div className="flex w-full flex-col gap-1">
        <div className="flex items-center">
          <div className="flex items-center gap-2">
            <div className="font-semibold">{item.name}</div>
            {!item.read && (
              <span className="flex h-2 w-2 rounded-full bg-blue-600" />
            )}
          </div>
          <div
            className={cn(
              "ml-auto text-xs",
              isSelected
                ? "text-foreground"
                : "text-muted-foreground"
            )}
          >
            {formatDistanceToNow(date, {
              addSuffix: true,
            })}
          </div>
        </div>
        <div className="text-xs font-medium">{item.subject}</div>
      </div>
      <div className="line-clamp-2 text-xs text-muted-foreground">
        {item.text.substring(0, 300)}
      </div>
      {item.labels.length ? (
        <div className="flex items-center gap-2">
          {item.labels.map((label) => (
            <Badge key={label.id} variant="default" style={{ backgroundColor: label.color }}>
              {label.name}
            </Badge>
          ))}
        </div>
      ) : null}
    </button>
  )
}
<?php return array('dependencies' => array(), 'version' => 'c80a48d4a0fa7b9513ed');
